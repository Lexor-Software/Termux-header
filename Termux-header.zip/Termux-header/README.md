# Termux-header script
swipe up throughout that icon
- [x] swich between two sessions `CTRL + 4` and `CTRL + 5`
- [x] other shortcuts need video guide.

## Download and installation steps

```bash 
apt update && yes | apt upgrade && apt update && apt install git -y
git clone https://github.com/Lexor-Software/Termux-header.git
cd Termux-header
bash Termux-header.sh

```
## For remove tool 
```bash
cd ~/Termux-header && bash Termux-header.sh --remove && exit
```
